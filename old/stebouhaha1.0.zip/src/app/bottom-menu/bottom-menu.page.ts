import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bottom-menu',
  templateUrl: './bottom-menu.page.html',
  styleUrls: ['./bottom-menu.page.scss'],
})
export class BottomMenuPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
