import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-marques',
  templateUrl: './marques.page.html',
  styleUrls: ['./marques.page.scss'],
})
export class MarquesPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
