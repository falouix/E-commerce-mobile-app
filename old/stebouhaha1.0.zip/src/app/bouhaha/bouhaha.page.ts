import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bouhaha',
  templateUrl: './bouhaha.page.html',
  styleUrls: ['./bouhaha.page.scss'],
})
export class BouhahaPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
