<?php
/**
 * Copyright since 2007 PrestaShop SA and Contributors
 * PrestaShop is an International Registered Trademark & Property of PrestaShop SA
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.md.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/OSL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to https://devdocs.prestashop.com/ for more information.
 *
 * @author    PrestaShop SA and Contributors <contact@prestashop.com>
 * @copyright Since 2007 PrestaShop SA and Contributors
 * @license   https://opensource.org/licenses/OSL-3.0 Open Software License (OSL 3.0)
 */
class AddressController extends AddressControllerCore
{
    public $auth = true;
    public $guestAllowed = true;
    public $php_self = 'address';
    public $authRedirection = 'addresses';
    public $ssl = true;

    protected $address_form;
    protected $should_redirect = false;

    /**
     * Initialize address controller.
     *
     * @see FrontController::init()
     */
    public function init()
    {
      
        if(isset($_GET['source']) && $_GET['source'] =='app'){
            $customer1 = new Customer((int) $_GET['id_customer'] );
            $this->context->customer = $customer1;
            $this->context->customer->logged = 1;
         }
         if(isset($_GET['appaction']) && $_GET['appaction'] =='updateaddress'){
            $customer1 = new Customer((int) $_GET['id_customer'] );
            $this->context->customer = $customer1;
            $this->context->customer->logged = 1;
         } 
        parent::init();
        
    }

    /**
     * Start forms process.
     *
     * @see FrontController::postProcess()
     */
    public function postProcess()
    {
       
  
        // Initialize address if an id exists
        if ($id_address  && !isset($_GET['source'])) {
            $this->address_form->loadAddressById($id_address);
        } 
      

        if ($id_address && isset($_GET['source']) && $_GET['appaction'] =='updateaddress') {
        //    echo'<pre>process 4';print_r(  $id_address );echo'</pre>';die();
            $this->address_form->loadAddressById($id_address);
        }
        // Fill the form with data

     

        if(isset($_GET['source']) && $_GET['source'] =='app'){
            $array_fillwith = Tools::getAllValues();
            //
            unset($array_fillwith['source']);
            unset($array_fillwith['id_customer']);
            $array_fillwith['token'] = Tools::getToken();
            $this->address_form->fillWith($array_fillwith);
            //echo('<pre>');print_r($array_fillwith);echo('</pre>');die();
          }else{
            $this->address_form->fillWith(Tools::getAllValues());
            //echo('<pre>');print_r(Tools::getAllValues());echo('</pre>');die();
          }
            
   
        // Submit the address, don't care if it's an edit or add
        if (Tools::isSubmit('submitAddress')) {
            
            if (!$this->address_form->submit()) {
                $this->errors[] = $this->trans('Please fix the error below.', [], 'Shop.Notifications.Error');
            } else {
                if ($id_address) {
                    $this->success[] = $this->trans('Address successfully updated!', [], 'Shop.Notifications.Success');
             
               
                } else {
                    $this->success[] = $this->trans('Address successfully added!', [], 'Shop.Notifications.Success');
                }

                $this->should_redirect = true;
            }
            if(isset($_GET['source']) && $_GET['source'] =='app'){
              echo(json_encode(['success'=>empty($this->errors)]));
            }
       
        }
        

        // There is no id_adress, no need to continue
        if (!$id_address) {
            return;
        }
      //echo'<pre>before delet ';print_r( $this->context->customer);echo'</pre>';die();   
        if (Tools::getValue('delete')) {


            if (
                Validate::isLoadedObject($this->context->cart)
                && ($this->context->cart->id_address_invoice == $id_address
                || $this->context->cart->id_address_delivery == $id_address)
            ) {
                $this->errors[] = $this->trans(
                    'Could not delete the address since it is used in the shopping cart.',
                    [],
                    'Shop.Notifications.Error'
                );

                return;
            }


            $ok = $this->makeAddressPersister()->delete(
                new Address($id_address, $this->context->language->id),
                Tools::getValue('token')
            );
            if ($ok) {
                $this->success[] = $this->trans('Address successfully deleted!', [], 'Shop.Notifications.Success');
                $this->should_redirect = true;
            } else {
                $this->errors[] = $this->trans('Could not delete address.', [], 'Shop.Notifications.Error');
            }


            if(isset($_GET['source']) && $_GET['source'] =='app'){
                echo(json_encode(['success'=>empty($this->errors)]));
              }
        } else {
            $this->context->smarty->assign('editing', true);
        }
    }

    /**
     * Assign template vars related to page content.
     *
     * @see FrontController::initContent()
     */
    public function initContent()
    {
        parent::initContent();
    }
}
