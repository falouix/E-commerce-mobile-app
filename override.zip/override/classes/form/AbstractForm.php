<?php
/**
 * Copyright since 2007 PrestaShop SA and Contributors
 * PrestaShop is an International Registered Trademark & Property of PrestaShop SA
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.md.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/OSL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to https://devdocs.prestashop.com/ for more information.
 *
 * @author    PrestaShop SA and Contributors <contact@prestashop.com>
 * @copyright Since 2007 PrestaShop SA and Contributors
 * @license   https://opensource.org/licenses/OSL-3.0 Open Software License (OSL 3.0)
 */
use PrestaShop\PrestaShop\Core\Foundation\Templating\RenderableProxy;
use Symfony\Component\Translation\TranslatorInterface;

abstract class AbstractForm implements AbstractFormCore
{
   

    public function validate()
    {
        $emptyIndex = 0;
        if($_GET['source']=='app' && $_GET['reason']=='inscrit'){
          $errorsArray =[] ; 
        }
        foreach ($this->formFields as $field) {
            if ($field->isRequired()) {
                if (!$field->getValue()) {
                    $field->addError(
                        $this->constraintTranslator->translate('required')
                    );

                    continue;
                } elseif (!$this->checkFieldLength($field)) {
                    $field->addError(
                        $this->translator->trans(
                            'The %1$s field is too long (%2$d chars max).',
                            [$field->getLabel(), $field->getMaxLength()],
                            'Shop.Notifications.Error'
                        )
                    );
                }
            } elseif (!$field->isRequired()) {
                if (!$field->getValue()) {
                    continue;
                } elseif (!$this->checkFieldLength($field)) {
                    $field->addError(
                        $this->translator->trans(
                            'The %1$s field is too long (%2$d chars max).',
                            [$field->getLabel(), $field->getMaxLength()],
                            'Shop.Notifications.Error'
                        )
                    );
                }
            }

            foreach ($field->getConstraints() as $constraint) {
                if (!Validate::$constraint($field->getValue())) {
                    $field->addError(
                        $this->constraintTranslator->translate($constraint)
                    );
                }
            }
            if($_GET['source']=='app' && $_GET['reason']=='inscrit'){ 
                if(!empty($field->getErrors())){
                    $emptyIndex = 1;
                }
                $errorsArray[] = ["fieldName"=>$field->getName(),"fieldError"=>$field->getErrors()] ; 
              }
        }
        if($_GET['source']=='app' && $_GET['reason']=='inscrit' && $emptyIndex){ 
            echo(json_encode(['succes'=>false,'data'=>$errorsArray]));
            die();  
        }

        return !$this->hasErrors();
    }
}
